<html>
    <head>
        <script src="//code.jquery.com/jquery-latest.min.js"></script>
        <script src="<?php echo $js ?>"></script>
        <link rel="stylesheet" href="<?php echo $css ?>" /> 
<!--        <link rel="stylesheet" href="<?php echo $stylecss ?>" />  -->
        
        <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css' />
        <script type="text/javascript" src="<?php echo $modernizr ?>"></script> 
        <noscript><link rel="stylesheet" type="text/css" href="<?php echo $nojscss ?>" /></noscript>     
        <script type="text/javascript" src="<?php echo $snsliderjs ?>"></script> 
        <style>
            .title{
                color: <?php echo get_option('snslider_base_color');?>;
            }
            .banner .dots li.active {
                background: <?php echo get_option('snslider_base_color');?>;
            }
            .fases {
                background: -webkit-linear-gradient(#B1B1B1, <?php echo get_option('snslider_base_color');?>); /* For Safari 5.1 to 6.0 */
                background: -o-linear-gradient(#B1B1B1, <?php echo get_option('snslider_base_color');?>); /* For Opera 11.1 to 12.0 */
                background: -moz-linear-gradient(#B1B1B1, <?php echo get_option('snslider_base_color');?>); /* For Firefox 3.6 to 15 */
                background: linear-gradient(#B1B1B1, <?php echo get_option('snslider_base_color');?>); /* Standard syntax */            
            }
            .links {
                background-color: <?php echo get_option('snslider_base_color');?>;
            }
            .fases div .selected{
                color: <?php echo get_option('snslider_base_color');?>;
            }
            .selects select{
                color: <?php echo get_option('snslider_base_color');?>;
            }
            .selects {
                background-color: <?php echo get_option('snslider_base_color');?>;

            }
            .nice_select {
                color: <?php echo get_option('snslider_base_color');?>;
            }
            .nice_select .dropdown li a {
                color: <?php echo get_option('snslider_base_color');?>;
            }
            .nice_select:after {
                border-color: <?php echo get_option('snslider_base_color');?> transparent;
            }
        </style>
        <script>
        </script>
    </head>
    <body>
        <div class="banner">
            <ul>
<?php
foreach($slides as $slide){
?>
                <li class="item">
                        <div class="header" style="background: url(<?php echo $slide['thumbnail'] ?>) no-repeat; background-size: 100%;">
                            <div class="title">
                                <?php echo $slide['title'] ?>
                            </div>
                            <div class="quotedivider">
                            </div>
                            <div class="quote">
                                <?php echo $slide['quote'] ?>
                            </div>
                        </div>
                        <div class="fase">
                            <div class="fases">
                                <div class="divider"></div> 
                                <div class="verbreden">verbreden</div>
                                <div class="evalueren">evalueren</div>
                                <div class="experimenteren">experimenteren</div>
                                <div class="adopteren">adopteren</div>
                                <div class="schetsen">schetsen</div>
                                <div class="initieren selected">initi&euml;ren</div>
<!--                                <?php echo $slide['fase'] ?> -->
                            </div>
                            <div class="links">
                                <div><a href="#">BLOG</a></div>
                                <div><a href="#">NIEUWS</a></div>
                                <div><a href="#">HET TEAM</a></div>
                            </div>
                        </div>
                        <div class="headertitle">
                            <div class="jaar">START: <span class="value"><?php echo $slide['jaar'] ?></span> </div>
                            <div class="trekker">TREKKER: <span class="value"><?php echo $slide['trekker'] ?></span> </div>
                            <div class="opdrachtgever">OPDRACHTGEVER: <span class="value"><?php echo $slide['opdrachtgever'] ?></span> </div>
                        </div>
                        <div class="fase_verbreden text">
                            <?php echo $slide['fase_verbreden'] ?>
                        </div>
                        <div class="fase_evalueren text">
                            <?php echo $slide['fase_evalueren'] ?>
                        </div>
                        <div class="fase_experimenteren text">
                            <?php echo $slide['fase_experimenteren'] ?>
                        </div>
                        <div class="fase_adopteren text">
                            <?php echo $slide['fase_adopteren'] ?>
                        </div>
                        <div class="fase_schetsen text">
                            <?php echo $slide['fase_schetsen'] ?>
                        </div>
                        <div class="fase_initieren text">
                            <?php echo $slide['fase_initieren'] ?>
                        </div>
                        <div class="selects">
                            <div id="dd2" class="select_jaar nice_select" tabindex="1"><span class="select_jaar_span">Jaar (alle)</span>
                                <ul class="dropdown">
                                    <li><a href="#">2014</a></li>
                                    <li><a href="#">2013</a></li>
                                    <li><a href="#">2012</a></li>
                                    <li><a href="#">2011</a></li>
                                    <li><a href="#">2010</a></li>
                                </ul>
                            </div>
                            <div id="dd1" class="select_fase nice_select" tabindex="1"><span class="select_fase_span">Fase (alle)</span>
                                <ul class="dropdown">
                                    <li class="verbreden"><a href="#">verbreden</a></li>
                                    <li class="evalueren"><a href="#">evalueren</a></li>
                                    <li class="experimenteren"><a href="#">experimenteren</a></li>
                                    <li class="adopteren"><a href="#">adopteren</a></li>
                                    <li class="schetsen"><a href="#">schetsen</a></li>
                                    <li class="initieren"><a href="#">initi&euml;ren</a></li>
                                </ul>
                            </div>

                        </div>
                </li>
<?php
}
?>
            </ul>
        </div>

    </body>
</html>

jQuery(document).ready(function($) {  
    $(".numeric").numeric();
});


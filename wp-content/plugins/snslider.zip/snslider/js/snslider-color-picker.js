jQuery(document).ready(function($) {  
  $('.snslider-color-picker').wpColorPicker();  
});

